HD handshake 0.1.0 - local validation artifact, NOT installed or hardware-tested.
ARMv7 hard-float, dynamic glibc <= 2.25. Loopback only; mock mode tested under QEMU.
No firmware, private device libraries, credentials, or installer included.
Run only in a controlled test environment. This is not a general Open-XiaoAI client.
Build source and notices: https://github.com/PangKuo510/xiaomi-xiaoai-hd
This artifact does not introduce a new public license for project-owned code.
Third-party rights remain with their respective authors; see bundled notices.
